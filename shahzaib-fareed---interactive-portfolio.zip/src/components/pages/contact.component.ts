
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-contact',
  imports: [CommonModule, RouterLink],
  template: `
    <div class="max-w-5xl mx-auto px-6 py-20">
      <a routerLink="/" class="inline-flex items-center gap-2 text-lg font-bold text-[#512E21] hover:opacity-75 transition-opacity mb-12">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
        </svg>
        Back Home
      </a>
      
      <div class="flex flex-col justify-center">
        <h1 class="text-7xl md:text-9xl font-extrabold tracking-tighter mb-12">Let's talk.</h1>
        
        <div class="grid md:grid-cols-2 gap-16">
          <div class="bg-[#B19CD9] p-12 rounded-[50px] flex flex-col">
            <p class="text-2xl font-bold mb-8">Ready to start a new project or just want to say hi?</p>
            <a href="mailto:zaybdeveloper@gmail.com" class="text-3xl md:text-4xl font-extrabold underline decoration-4 underline-offset-8 hover:text-white transition-all">zaybdeveloper@gmail.com</a>
            <p class="text-2xl font-bold mt-4">+92 334 9224708</p>
            
            <div class="mt-16 flex flex-col gap-6">
              <a href="#" class="inline-flex items-center justify-center gap-3 w-full bg-white/20 hover:bg-white/40 text-[#512E21] font-bold text-lg px-8 py-4 rounded-full transition-colors">
                <svg class="w-6 h-6" viewBox="0 0 24 24" fill="currentColor"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                Connect on LinkedIn
              </a>
              <div class="flex justify-center gap-6">
                <a href="#" class="font-bold uppercase tracking-widest text-sm border-b-2 border-black">Insta</a>
                <a href="#" class="font-bold uppercase tracking-widest text-sm border-b-2 border-black">Facebook</a>
                <a href="#" class="font-bold uppercase tracking-widest text-sm border-b-2 border-black">Indeed</a>
                <a href="#" class="font-bold uppercase tracking-widest text-sm border-b-2 border-black">Upwork</a>
              </div>
            </div>
          </div>
          
          <div class="flex flex-col justify-end">
            <div class="p-8 bg-neutral-100 rounded-[30px] mb-6">
              <h4 class="font-bold uppercase tracking-widest text-xs text-neutral-400 mb-2">Current Location</h4>
              <p class="text-xl font-bold">Remote / Worldwide</p>
            </div>
            <div class="p-8 bg-neutral-100 rounded-[30px]">
              <h4 class="font-bold uppercase tracking-widest text-xs text-neutral-400 mb-2">Availability</h4>
              <p class="text-xl font-bold">Booking for Q3 2024</p>
            </div>
          </div>
        </div>
      </div>
      
      <div class="pt-20 text-sm font-bold uppercase tracking-widest text-neutral-400">
        © 2024 Shahzaib Fareed. All rights reserved.
      </div>
    </div>
  `
})
export class ContactComponent {}
