
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-projects',
  imports: [CommonModule, RouterLink],
  template: `
    <div class="max-w-6xl mx-auto px-6 py-20">
      <a routerLink="/" class="inline-flex items-center gap-2 text-lg font-bold text-[#512E21] hover:opacity-75 transition-opacity mb-12">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
        </svg>
        Back Home
      </a>
      
      <h1 class="text-7xl font-extrabold tracking-tighter mb-16">Selected Work</h1>

      <div class="grid md:grid-cols-2 gap-8">
        @for (project of projects; track project.title) {
          <div class="group bg-[#AEC6CF] rounded-[48px] overflow-hidden transition-all duration-500 hover:shadow-2xl">
            <div class="aspect-[16/10] overflow-hidden">
              <img [src]="project.image" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" [alt]="project.title">
            </div>
            <div class="p-10">
              <h3 class="text-3xl font-extrabold mb-2">{{ project.title }}</h3>
              <p class="text-neutral-700 font-medium mb-6">{{ project.type }}</p>
              <div class="flex justify-between items-center">
                <div class="flex gap-2">
                  @for (tool of project.tools; track tool) {
                    <span class="w-2 h-2 rounded-full bg-white"></span>
                  }
                </div>
                <a href="#" class="text-sm font-bold uppercase tracking-widest underline decoration-2 underline-offset-4">View Case Study →</a>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class ProjectsComponent {
  projects = [
    {
      title: 'Aura Fitness',
      type: 'E-commerce & Web App',
      image: 'https://picsum.photos/1200/800?random=10',
      tools: [1, 2, 3]
    },
    {
      title: 'Neura Analytics',
      type: 'SaaS Dashboard',
      image: 'https://picsum.photos/1200/800?random=11',
      tools: [1, 2, 3]
    },
    {
      title: 'The Nomad Journal',
      type: 'Editorial Platform',
      image: 'https://picsum.photos/1200/800?random=12',
      tools: [1, 2, 3]
    },
    {
      title: 'Zen Workspace',
      type: 'Brand Identity & Web',
      image: 'https://picsum.photos/1200/800?random=13',
      tools: [1, 2, 3]
    }
  ];
}
