
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-experience',
  imports: [CommonModule, RouterLink],
  template: `
    <div class="max-w-5xl mx-auto px-6 py-20">
      <a routerLink="/" class="inline-flex items-center gap-2 text-lg font-bold text-[#512E21] hover:opacity-75 transition-opacity mb-12">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
        </svg>
        Back Home
      </a>
      
      <h1 class="text-7xl font-extrabold tracking-tighter mb-16">Career Journey</h1>

      <div class="space-y-12">
        @for (item of experiences; track item.title) {
          <div class="group bg-[#C1E1C1] p-10 rounded-[40px] transition-transform hover:-translate-y-2 duration-500">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
              <div>
                <span class="text-sm font-bold uppercase tracking-widest text-neutral-600 mb-2 block">{{ item.period }}</span>
                <h3 class="text-4xl font-extrabold">{{ item.title }}</h3>
              </div>
              <div class="text-xl font-bold mt-4 md:mt-0 opacity-60">{{ item.company }}</div>
            </div>
            <p class="text-xl text-neutral-800 leading-relaxed max-w-3xl mb-8">
              {{ item.description }}
            </p>
            <div class="flex flex-wrap gap-3">
              @for (tag of item.tags; track tag) {
                <span class="px-4 py-2 bg-white rounded-full text-xs font-bold uppercase tracking-wider">{{ tag }}</span>
              }
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class ExperienceComponent {
  experiences = [
    {
      title: 'Senior Web Architect',
      company: 'TechFlow Solutions',
      period: '2022 - Present',
      description: 'Leading a team of developers to build scalable enterprise solutions. Implemented a custom SEO framework that increased organic traffic by 150% within 6 months.',
      tags: ['Angular', 'Next.js', 'Node.js', 'SEO Strategy']
    },
    {
      title: 'Full Stack Developer',
      company: 'Creative Studio X',
      period: '2020 - 2022',
      description: 'Focused on creating high-end interactive experiences for luxury brands. Mastered motion design and SVG animation techniques for premium web interfaces.',
      tags: ['TypeScript', 'Three.js', 'GSAP', 'Tailwind']
    },
    {
      title: 'Junior Web Developer',
      company: 'Bright Digital',
      period: '2019 - 2020',
      description: 'Started the journey by building robust CMS-driven websites and learning the foundations of technical SEO and accessibility.',
      tags: ['HTML/CSS', 'JavaScript', 'WordPress', 'SEO Basics']
    }
  ];
}
