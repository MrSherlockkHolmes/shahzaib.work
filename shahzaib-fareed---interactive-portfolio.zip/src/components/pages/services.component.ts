
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-services',
  imports: [CommonModule, RouterLink],
  template: `
    <div class="max-w-5xl mx-auto px-6 py-20">
      <a routerLink="/" class="inline-flex items-center gap-2 text-lg font-bold text-[#512E21] hover:opacity-75 transition-opacity mb-12">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
        </svg>
        Back Home
      </a>
      
      <h1 class="text-7xl font-extrabold tracking-tighter mb-16">How I help</h1>

      <div class="grid gap-6">
        @for (service of services; track service.title) {
          <div class="p-12 bg-[#FDFD96] rounded-[40px] flex flex-col md:flex-row gap-8 items-center">
            <div class="w-24 h-24 bg-white rounded-full flex items-center justify-center text-4xl shrink-0 shadow-sm">
              {{ service.icon }}
            </div>
            <div>
              <h2 class="text-3xl font-extrabold mb-4">{{ service.title }}</h2>
              <p class="text-xl text-neutral-700 mb-6 leading-relaxed">{{ service.description }}</p>
              <div class="flex flex-wrap gap-2">
                @for (item of service.items; track item) {
                  <span class="text-xs font-bold px-3 py-1 bg-white/50 rounded-full uppercase">{{ item }}</span>
                }
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class ServicesComponent {
  services = [
    {
      icon: '💻',
      title: 'Full Stack Development',
      description: 'Building high-speed, modern web applications that scale. I focus on performance, SEO, and exceptionally smooth user experiences.',
      items: ['React / Next.js', 'Angular', 'Zoneless Rendering', 'Cloud Infrastructure']
    },
    {
      icon: '📈',
      title: 'Technical SEO',
      description: 'Optimizing the very core of your digital presence. I ensure your site isn\'t just pretty, but visible to the people who matter most.',
      items: ['Core Web Vitals', 'Semantic HTML', 'Rich Snippets', 'Content Strategy']
    },
    {
      icon: '🎨',
      title: 'Interaction Design',
      description: 'Adding that "magic" layer to your interfaces. Motion design that feels natural and boosts user engagement without clutter.',
      items: ['SVG Animation', 'Micro-interactions', 'User Journey Mapping', 'Motion Logic']
    }
  ];
}
