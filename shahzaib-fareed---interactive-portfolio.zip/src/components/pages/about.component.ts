
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-about',
  imports: [CommonModule, RouterLink],
  template: `
    <div class="max-w-5xl mx-auto px-6 py-20">
      <a routerLink="/" class="inline-flex items-center gap-2 text-lg font-bold text-[#512E21] hover:opacity-75 transition-opacity mb-12">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
        </svg>
        Back Home
      </a>
      
      <header class="mb-16">
        <h1 class="text-7xl font-extrabold tracking-tighter mb-4">I build products that people love.</h1>
        <p class="text-2xl text-neutral-500 max-w-2xl">I'm Shahzaib Fareed, a digital craftsman specialized in high-performance web development and strategic SEO.</p>
      </header>

      <div class="grid md:grid-cols-2 gap-12">
        <div class="bg-[#FFD1DC] p-12 rounded-[40px] aspect-square flex items-center justify-center">
          <img src="https://picsum.photos/600/600?random=1" class="rounded-3xl shadow-xl w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700" alt="Profile">
        </div>
        <div class="flex flex-col justify-center space-y-6">
          <h2 class="text-4xl font-bold">My Philosophy</h2>
          <p class="text-lg text-neutral-600 leading-relaxed">
            I believe that every line of code should serve a purpose. In 4+ years of professional experience, I've learned that technical excellence is only half the battle—the other half is empathy for the user.
          </p>
          <p class="text-lg text-neutral-600 leading-relaxed">
            Whether it's optimizing a React application for lightning speed or architecting an SEO strategy that dominates search results, I prioritize clean engineering and measurable results.
          </p>
          <div class="flex gap-4 pt-4">
             <div class="px-6 py-3 bg-neutral-100 rounded-full font-bold text-sm">Web Development</div>
             <div class="px-6 py-3 bg-neutral-100 rounded-full font-bold text-sm">SEO Architecture</div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AboutComponent {}
