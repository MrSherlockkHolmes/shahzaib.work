
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule],
  template: `
    <footer class="bg-[#512E21] text-[#F9F4EC] p-8 md:p-16">
      <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start gap-12">
        <!-- Left Side: Logo and Copyright -->
        <div class="flex flex-col">
          <div class="flex flex-col -space-y-1 mb-4">
            <span class="text-3xl font-extrabold tracking-tight">Shahzaib's</span>
            <span class="text-lg font-bold uppercase tracking-widest italic opacity-40">Workspace</span>
          </div>
          <p class="text-sm opacity-50 mt-auto">© 2024 Shahzaib Fareed. All rights reserved.</p>
        </div>

        <!-- Right Side: Contact and Socials -->
        <div class="flex flex-col md:items-end gap-6 w-full md:w-auto">
          <div class="text-left md:text-right">
            <a href="mailto:zaybdeveloper@gmail.com" class="text-xl font-bold hover:opacity-75 transition-opacity">zaybdeveloper@gmail.com</a>
            <p class="text-lg font-medium opacity-75">+92 334 9224708</p>
          </div>
          <div class="flex items-center gap-4">
            @for (social of socials; track social.name) {
              <a [href]="social.url" [title]="social.name" target="_blank" class="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-colors">
                <svg [innerHTML]="social.icon" class="w-5 h-5 fill-current"></svg>
              </a>
            }
          </div>
        </div>
      </div>
    </footer>
  `
})
export class FooterComponent {
  socials = [
    { name: 'LinkedIn', url: '#', icon: '<path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>' },
    { name: 'Instagram', url: '#', icon: '<path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.162 6.162 6.162 6.162-2.759 6.162-6.162-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4s1.791-4 4-4 4 1.79 4 4-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44 1.441-.645 1.441-1.44-.645-1.44-1.441-1.44z"/>' },
    { name: 'Facebook', url: '#', icon: '<path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v2.385z"/>' },
    { name: 'Indeed', url: '#', icon: '<path d="M12.4,9.1c-1.2,0-2.3-1.1-2.3-2.3s1.1-2.3,2.3-2.3s2.3,1.1,2.3,2.3S13.6,9.1,12.4,9.1z M20.9,0H3.1C1.4,0,0,1.4,0,3.1v17.8 C0,22.6,1.4,24,3.1,24h17.8c1.7,0,3.1-1.4,3.1-3.1V3.1C24,1.4,22.6,0,20.9,0z M8.9,20.5H5.4V9.6h3.5V20.5z M7.2,8.4 C6,8.4,5,7.4,5,6.2s1-2.2,2.2-2.2s2.2,1,2.2,2.2S8.4,8.4,7.2,8.4z M20.5,20.5h-3.5v-5.6c0-1.3,0-3-1.8-3s-2.1,1.4-2.1,2.9v5.7h-3.5 V9.6h3.4v1.5h0c0.5-0.9,1.6-1.8,3.3-1.8c3.5,0,4.2,2.3,4.2,5.3V20.5z"/>' },
    { name: 'Upwork', url: '#', icon: '<path d="M16.5,8.8c-2.4,0-4.1,1.8-4.7,4.3h-0.1c-0.2-1.2-0.5-2.2-1.1-2.8c-0.6-0.7-1.5-1-2.6-1c-1.3,0-2.5,0.6-3.4,1.8 c-0.8,1.1-1.1,2.6-1.1,4.3v6.5H0V15c0-2.4,0.7-4.4,2-6.1c1.3-1.7,3.2-2.5,5.6-2.5c1.4,0,2.6,0.3,3.7,1c1.1,0.7,2,1.8,2.5,3 c0.9-1.9,2.6-3,4.8-3c3,0,4.8,2.3,4.8,5.7v7.8h-3.4V15.1C21.4,11.3,19.3,8.8,16.5,8.8z"/>' }
  ];
}
