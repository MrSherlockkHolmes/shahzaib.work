
import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CentralCharacterComponent } from './central-character.component';
import { BubbleComponent } from './bubble.component';
import { Router } from '@angular/router';

export type BubbleType = 'about' | 'experience' | 'projects' | 'services' | 'contact' | null;

@Component({
  selector: 'app-home',
  imports: [CommonModule, CentralCharacterComponent, BubbleComponent],
  template: `
    <div 
      class="relative w-screen h-screen flex flex-col md:items-center md:justify-center transition-colors duration-700 overflow-hidden select-none"
      [class.bg-[#F9F4EC]]="!isDark()"
      [class.bg-[#0A0A0A]]="isDark()"
      [class.dark-mode]="isDark()"
    >
      <!-- Mobile Warning Banner -->
      <div class="md:hidden w-full p-2 bg-green-100 text-green-800 text-center text-sm font-semibold z-50">
        <span class="mr-2">✨</span> View on your computer for the best experience.
      </div>
      
      <!-- Header -->
      <header class="relative p-4 md:absolute md:p-0 md:top-10 md:left-12 md:right-12 flex items-center justify-between md:justify-start gap-8 z-40">
        <!-- Logo & Toggle Container -->
        <div class="flex items-center gap-4 md:gap-8">
          <!-- Logo -->
          <div class="flex items-center gap-2 md:gap-3 group">
            <div class="w-10 h-10 md:w-12 md:h-12 bg-[#FFD1DC] rounded-xl md:rounded-2xl flex items-center justify-center shadow-md group-hover:rotate-12 transition-transform duration-500">
              <span class="text-xl md:text-2xl">🐹</span>
            </div>
            <div class="flex flex-col -space-y-1">
              <span class="text-lg md:text-xl font-extrabold tracking-tight transition-colors duration-500" [class.text-[#512E21]]="!isDark()" [class.text-[#F9F4EC]]="isDark()">Shahzaib's</span>
              <span class="text-xs md:text-sm font-bold uppercase tracking-widest italic transition-opacity duration-500" [class.text-[#512E21]/60]="!isDark()" [class.text-[#F9F4EC]/40]="isDark()">Workspace</span>
            </div>
          </div>

          <!-- Mode Toggle -->
          <button 
            (click)="toggleTheme()"
            class="hidden md:flex w-16 h-8 rounded-full p-1 relative transition-colors duration-500 shadow-inner items-center"
            [style.background-color]="isDark() ? '#2D2D2D' : '#E5E0D5'"
          >
            <div 
              class="w-6 h-6 rounded-full flex items-center justify-center shadow-lg transition-all duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)]"
              [style.background-color]="isDark() ? '#F9F4EC' : '#FFCB45'"
              [style.transform]="isDark() ? 'translateX(32px)' : 'translateX(0px)'"
            >
              @if (isDark()) {
                <span class="text-xs">🌙</span>
              } @else {
                <span class="text-xs">☀️</span>
              }
            </div>
          </button>
        </div>

        <!-- Desktop Navigation -->
        <nav 
          class="hidden md:flex absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 items-center gap-6 font-medium text-lg transition-colors duration-500"
          [class.text-[#512E21]]="!isDark()"
          [class.text-[#F9F4EC]]="isDark()"
        >
          <a (click)="onBubbleClick('/projects')" class="cursor-pointer hover:opacity-70 transition-opacity">UXUI Projects</a>
          <div class="w-[1px] h-4 transition-colors duration-500" [class.bg-[#512E21]/20]="!isDark()" [class.bg-[#F9F4EC]/20]="isDark()"></div>
          <a (click)="onBubbleClick('/experience')" class="cursor-pointer hover:opacity-70 transition-opacity">Experience</a>
          <div class="w-[1px] h-4 transition-colors duration-500" [class.bg-[#512E21]/20]="!isDark()" [class.bg-[#F9F4EC]/20]="isDark()"></div>
          <a (click)="onBubbleClick('/contact')" class="cursor-pointer hover:opacity-70 transition-opacity">Contact Me</a>
          <div class="w-[1px] h-4 transition-colors duration-500" [class.bg-[#512E21]/20]="!isDark()" [class.bg-[#F9F4EC]/20]="isDark()"></div>
          <a (click)="onBubbleClick('/about')" class="cursor-pointer hover:opacity-70 transition-opacity">About Me</a>
        </nav>
        
        <!-- Mobile Hamburger Menu -->
        <button (click)="isMobileMenuOpen.set(true)" class="md:hidden p-2">
            <svg class="w-8 h-8" [class.text-[#512E21]]="!isDark()" [class.text-[#F9F4EC]]="isDark()" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" />
            </svg>
        </button>
      </header>

      <!-- Mobile Menu Overlay -->
      @if (isMobileMenuOpen()) {
        <div class="fixed inset-0 bg-[#A8E6A8] z-[100] flex flex-col p-4 animate-in fade-in slide-in-from-right-full duration-500">
          <div class="flex justify-between items-center mb-16">
            <div class="text-2xl font-bold text-[#512E21]">shahzaib.work</div>
            <button (click)="isMobileMenuOpen.set(false)" class="p-2">
              <svg class="w-8 h-8 text-[#512E21]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <nav class="flex flex-col items-center gap-10">
            @for(item of mobileNavItems; track item.label) {
              <a (click)="onMobileNavClick(item.route)" class="flex items-center gap-4 text-3xl font-bold text-[#512E21]">
                <div class="w-12 h-12 rounded-full bg-yellow-200 flex items-center justify-center text-2xl">{{item.emoji}}</div>
                <span>{{item.label}}</span>
              </a>
            }
          </nav>
        </div>
      }

      <!-- Main Content -->
      <div class="relative flex-grow w-full flex items-center justify-center">

        <!-- Mobile Layout -->
        <div class="block md:hidden w-full h-full relative">
          <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 scale-75">
            <app-central-character [expression]="activeBubble()" [isDark]="isDark()"></app-central-character>
          </div>
          
          <!-- Mobile Bubbles -->
          <div (click)="onBubbleClick('/contact')" class="absolute top-[20%] right-[10%] text-center">
             <div class="text-3xl font-bold text-[#512E21]">Contact me</div>
             <div class="w-20 h-20 bg-green-300 rounded-full flex items-center justify-center mt-2 text-3xl shadow-lg">🤗</div>
          </div>
           <div (click)="onBubbleClick('/projects')" class="absolute top-[35%] left-[5%] text-center">
             <div class="text-3xl font-bold text-[#512E21]">Projects</div>
             <div class="w-20 h-20 bg-green-300 rounded-full flex items-center justify-center mt-2 text-3xl shadow-lg">😍</div>
          </div>
           <div (click)="onBubbleClick('/about')" class="absolute bottom-[20%] left-[15%] text-center">
             <div class="w-20 h-20 bg-green-300 rounded-full flex items-center justify-center mb-2 text-3xl shadow-lg">😎</div>
             <div class="text-3xl font-bold text-[#512E21]">About me</div>
          </div>
           <div (click)="onBubbleClick('/experience')" class="absolute bottom-[25%] right-[5%] text-center">
             <div class="w-20 h-20 bg-green-300 rounded-full flex items-center justify-center mb-2 text-3xl shadow-lg">😋</div>
             <div class="text-3xl font-bold text-[#512E21]">Experience</div>
          </div>

          <!-- Decorative elements -->
          <div class="absolute top-[28%] right-[32%] w-8 h-8 bg-orange-300 rounded-full"></div>
          <div class="absolute top-[20%] left-[30%] w-6 h-6 bg-yellow-300 rounded-full"></div>
          <div class="absolute bottom-[20%] right-[35%] w-12 h-12 bg-orange-400 rounded-full"></div>
        </div>
        
        <!-- Desktop Layout -->
        <div class="hidden md:block">
          <!-- Central Character -->
          <app-central-character [expression]="activeBubble()" [isDark]="isDark()"></app-central-character>
          <!-- Floating Bubbles -->
          @for (bubble of bubbles; track bubble.id) {
            <app-bubble
              [config]="bubble"
              [isActive]="activeBubble() === bubble.id"
              [isDimmed]="activeBubble() !== null && activeBubble() !== bubble.id"
              [isDark]="isDark()"
              (hovered)="onBubbleHover(bubble.id)"
              (unhovered)="onBubbleHover(null)"
              (clicked)="onBubbleClick(bubble.route)"
            ></app-bubble>
          }
        </div>

      </div>

      <!-- Signature Hero Text (Bottom Left) -->
      <div class="absolute bottom-8 left-4 md:bottom-16 md:left-16 max-w-md z-20 pointer-events-none">
        <p class="text-sm md:text-base font-medium mb-1 transition-colors duration-500" [class.text-[#512E21]/60]="!isDark()" [class.text-[#F9F4EC]/40]="isDark()">Shahzaib specializes in designing</p>
        <h2 
          class="text-4xl md:text-5xl font-bold leading-[1.1] tracking-tight transition-colors duration-500"
          [class.text-[#512E21]]="!isDark()"
          [class.text-[#F9F4EC]]="isDark()"
        >
          Interactive Web<br>& Applications
        </h2>
      </div>

      <!-- Bottom Chat Icon -->
      <div 
        class="absolute bottom-4 right-4 md:bottom-8 md:right-8 w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg cursor-pointer hover:scale-110 transition-all duration-500"
        [class.bg-[#88D66C]]="!isDark()"
        [class.bg-[#FFCB45]]="isDark()"
        [class.shadow-[0_0_20px_rgba(255,203,69,0.5)]]="isDark()"
      >
        <svg viewBox="0 0 24 24" class="w-7 h-7" [class.fill-[#512E21]]="true">
          <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z" />
        </svg>
      </div>
    </div>
  `
})
export class HomeComponent {
  activeBubble = signal<BubbleType>(null);
  isDark = signal(false);
  isMobileMenuOpen = signal(false);

  mobileNavItems = [
      { label: 'Projects', route: '/projects', emoji: '😍' },
      { label: 'Experience', route: '/experience', emoji: '😋' },
      { label: 'About Me', route: '/about', emoji: '😎' },
      { label: 'Contact Me', route: '/contact', emoji: '🤗' }
  ];

  bubbles = [
    { 
      id: 'about' as const, label: 'About me', color: '#88D66C', 
      route: '/about', x: -220, y: 150, size: 180, delay: '0s' 
    },
    { 
      id: 'projects' as const, label: 'Projects', color: '#88D66C', 
      route: '/projects', x: -260, y: -60, size: 140, delay: '1s' 
    },
    { 
      id: 'experience' as const, label: 'Experience', color: '#FF9F43', 
      route: '/experience', x: 260, y: 150, size: 200, delay: '0.5s' 
    },
    { 
      id: 'services' as const, label: 'Services', color: '#FFCB45', 
      route: '/services', x: 120, y: -240, size: 90, delay: '1.5s' 
    },
    { 
      id: 'contact' as const, label: 'Contact', color: '#FAD6A5', 
      route: '/contact', x: 240, y: -80, size: 110, delay: '2s' 
    },
    { id: 'dec1' as any, label: '', color: '#FFCB45', route: '', x: 150, y: 300, size: 40, delay: '3s' },
    { id: 'dec2' as any, label: '', color: '#FFB84C', route: '', x: -100, y: -320, size: 30, delay: '4s' },
    { id: 'dec3' as any, label: '', color: '#FAD6A5', route: '', x: -380, y: -50, size: 50, delay: '2.5s' }
  ];

  constructor(private router: Router) {}

  toggleTheme() {
    this.isDark.update(v => !v);
  }

  onBubbleHover(type: BubbleType) {
    this.activeBubble.set(type);
  }

  onBubbleClick(route: string) {
    if (route) this.router.navigate([route]);
  }

  onMobileNavClick(route: string) {
    this.isMobileMenuOpen.set(false);
    this.router.navigate([route]);
  }
}
