import { Component, input, output, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-bubble',
  imports: [CommonModule],
  template: `
    <div 
      class="absolute cursor-pointer transition-all duration-700 ease-[cubic-bezier(0.23,1,0.32,1)] floating group"
      [style.left.px]="coords().x"
      [style.top.px]="coords().y"
      [style.width.px]="config().size"
      [style.height.px]="config().size"
      [style.animation-delay]="config().delay"
      [style.opacity]="isDimmed() ? (isDark() ? 0.2 : 0.6) : 1"
      [style.transform]="isActive() ? 'scale(1.15)' : 'scale(1)'"
      [style.z-index]="isActive() ? 100 : 20"
      (mouseenter)="hovered.emit()"
      (mouseleave)="unhovered.emit()"
      (click)="clicked.emit()"
    >
      <!-- Main Bubble Circle -->
      <div 
        class="w-full h-full rounded-full transition-all duration-700 relative flex items-center justify-center overflow-visible shadow-lg"
        [style.background-color]="config().color"
        [class.burning-effect]="isDark()"
      >
        <!-- Mini Face on Hover -->
        @if (isActive() && config().label) {
          <div class="absolute inset-0 flex items-center justify-center animate-in fade-in zoom-in duration-300">
             <svg viewBox="0 0 40 40" class="w-[60%] h-[60%] drop-shadow-sm overflow-visible">
                <!-- Eyes -->
                @if (config().id === 'projects' || config().id === 'about') {
                  <path d="M 8 18 Q 12 21 16 18" fill="none" stroke="#512E21" stroke-width="2.5" stroke-linecap="round" />
                  <circle cx="28" cy="18" r="3" fill="#512E21" />
                } @else {
                  <circle cx="12" cy="18" r="3" fill="#512E21" />
                  <circle cx="28" cy="18" r="3" fill="#512E21" />
                }
                
                <!-- Mouth -->
                <path d="M 14 28 Q 20 34 26 28" fill="none" stroke="#512E21" stroke-width="2.5" stroke-linecap="round" />
                
                <!-- Tongue -->
                @if (config().id === 'about') {
                   <path d="M 23 30 Q 25 35 27 30 Z" fill="#FF0000" stroke="#512E21" stroke-width="1.5" />
                   <circle cx="25" cy="31" r="2.5" fill="#FF0000" stroke="#512E21" stroke-width="1.5" />
                }

                <!-- Cheeks -->
                <circle cx="6" cy="22" r="4" fill="#FF0000" />
                <circle cx="34" cy="22" r="4" fill="#FF0000" />
             </svg>
          </div>
          
          <!-- Label Text -->
          <div class="absolute -top-16 left-1/2 -translate-x-1/2 whitespace-nowrap z-[110]">
            <span class="text-3xl md:text-5xl font-extrabold text-[#512E21] text-outline tracking-tight transition-all duration-500">
              {{ config().label }}
            </span>
          </div>
        }
      </div>
    </div>
  `
})
export class BubbleComponent {
  config = input.required<{ id: string, label: string, color: string, x: number, y: number, size: number, delay: string }>();
  isActive = input<boolean>(false);
  isDimmed = input<boolean>(false);
  isDark = input<boolean>(false);
  
  hovered = output<void>();
  unhovered = output<void>();
  clicked = output<void>();

  coords = computed(() => {
    const cfg = this.config();
    const active = this.isActive();
    
    const w = typeof window !== 'undefined' ? window.innerWidth : 1920;
    const h = typeof window !== 'undefined' ? window.innerHeight : 1080;

    const centerX = w / 2 - (cfg.size / 2);
    const centerY = h / 2 - (cfg.size / 2);
    
    const pullX = active ? cfg.x * 0.85 : cfg.x;
    const pullY = active ? cfg.y * 0.85 : cfg.y;

    return {
      x: centerX + pullX,
      y: centerY + pullY
    };
  });
}