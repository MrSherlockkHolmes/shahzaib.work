import { Component, input, computed, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BubbleType } from './home.component';

@Component({
  selector: 'app-central-character',
  imports: [CommonModule],
  template: `
    <div class="relative w-[320px] h-[320px] md:w-[420px] md:h-[420px] flex items-center justify-center transition-all duration-700">
      <!-- Yellow Body -->
      <div 
        class="absolute inset-0 rounded-full bg-[#FFCB45] breathing shadow-sm transition-all duration-700"
        [class.burning-effect]="isDark()"
      ></div>

      <svg viewBox="0 0 100 100" class="relative w-full h-full p-16 z-10 drop-shadow-sm overflow-visible">
        <!-- Eyes -->
        <g class="path-transition">
          @if (isBlinking() || currentExpression().wink) {
            <!-- Left Eye (Wink) -->
            <path [attr.d]="(currentExpression().wink && !isBlinking()) ? 'M 25 45 Q 35 48 45 45' : (isBlinking() ? 'M 25 45 Q 35 48 45 45' : 'M 25 45 Q 35 48 45 45')" 
                  fill="none" stroke="#512E21" stroke-width="4" stroke-linecap="round" />
            
            <!-- Right Eye -->
            @if (currentExpression().wink && !isBlinking()) {
               <circle cx="65" cy="45" r="7.5" fill="#512E21" [style.transform]="eyeTransform()" class="transition-transform duration-300" />
            } @else {
               <path d="M 55 45 Q 65 48 75 45" fill="none" stroke="#512E21" stroke-width="4" stroke-linecap="round" />
            }
          } @else {
            <!-- Left Eye -->
            <g [style.transform]="eyeTransform()" class="transition-transform duration-300 ease-out">
              <circle cx="35" cy="45" r="7.5" fill="#512E21" />
              <circle cx="32" cy="42" r="2.5" fill="white" />
            </g>
            <!-- Right Eye -->
            <g [style.transform]="eyeTransform()" class="transition-transform duration-300 ease-out">
              <circle cx="65" cy="45" r="7.5" fill="#512E21" />
              <circle cx="62" cy="42" r="2.5" fill="white" />
            </g>
          }
        </g>

        <!-- Nose -->
        <path d="M 46 54 Q 50 56 54 54" fill="none" stroke="#512E21" stroke-width="1.5" stroke-linecap="round" />

        <!-- Mouth -->
        <g class="path-transition">
           <!-- Outer Lip -->
           <path [attr.d]="currentExpression().mouth" [attr.fill]="currentExpression().mouthFill || '#fff'" stroke="#512E21" stroke-width="2.5" stroke-linejoin="round" />
           
           <!-- Tongue Blob (for licking) -->
           @if (currentExpression().tongue) {
             <circle cx="58" cy="72" r="6" fill="#FF0000" stroke="#512E21" stroke-width="2" class="animate-pulse" />
           }

           <!-- Tooth Lines (Idle only) -->
           @if (isIdle()) {
             <path d="M 43 71 L 43 82 M 50 71 L 50 83 M 57 71 L 57 82" stroke="#512E21" stroke-width="1.5" />
           }
        </g>
        
        <!-- Bright Red Cheeks -->
        <g class="path-transition">
          <circle cx="18" cy="55" r="8" fill="#FF0000" />
          <circle cx="82" cy="55" r="8" fill="#FF0000" />
        </g>
      </svg>
    </div>
  `
})
export class CentralCharacterComponent {
  expression = input<BubbleType>(null);
  isDark = input<boolean>(false);
  
  isBlinking = signal(false);
  eyeOffsetX = signal(0);
  eyeOffsetY = signal(0);

  private readonly expressions: Record<string, any> = {
    idle: {
      mouth: 'M 32 72 Q 50 90 68 72 Q 50 85 32 72 Z',
      eyeLook: { x: 0, y: 0 }
    },
    about: {
      mouth: 'M 40 68 Q 55 75 70 68',
      tongue: true,
      wink: true,
      eyeLook: { x: -8, y: 8 }
    },
    experience: {
      mouth: 'M 38 72 Q 50 78 62 72',
      eyeLook: { x: 8, y: 8 }
    },
    projects: {
      mouth: 'M 32 68 Q 50 88 68 68',
      wink: true,
      eyeLook: { x: -10, y: -2 }
    },
    services: {
      mouth: 'M 35 65 Q 50 75 65 65',
      eyeLook: { x: 6, y: -10 }
    },
    contact: {
      mouth: 'M 32 72 Q 50 88 68 72',
      eyeLook: { x: 10, y: -4 }
    }
  };

  currentExpression = computed(() => {
    const exp = this.expression();
    return this.expressions[exp as string] || this.expressions['idle'];
  });

  isIdle = computed(() => !this.expression());

  eyeTransform = computed(() => {
    return `translate(${this.eyeOffsetX()}px, ${this.eyeOffsetY()}px)`;
  });

  constructor() {
    this.startBlinkLoop();
    this.startEyeMovementLoop();
    
    effect(() => {
      const exp = this.expression();
      if (exp && this.expressions[exp as string]) {
        const look = this.expressions[exp as string].eyeLook;
        this.eyeOffsetX.set(look.x);
        this.eyeOffsetY.set(look.y);
      }
    });
  }

  private startBlinkLoop() {
    const blink = () => {
      this.isBlinking.set(true);
      setTimeout(() => {
        this.isBlinking.set(false);
        setTimeout(blink, Math.random() * 4000 + 2000);
      }, 150);
    };
    setTimeout(blink, 3000);
  }

  private startEyeMovementLoop() {
    const lookAround = () => {
      if (this.isIdle()) {
        const newX = (Math.random() - 0.5) * 4; 
        const newY = (Math.random() - 0.5) * 2; 
        this.eyeOffsetX.set(newX);
        this.eyeOffsetY.set(newY);
      }
      setTimeout(lookAround, Math.random() * 3000 + 2000);
    };
    setTimeout(lookAround, 1000);
  }
}