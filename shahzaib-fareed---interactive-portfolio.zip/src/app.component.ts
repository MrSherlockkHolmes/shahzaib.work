
import { Component, inject, effect } from '@angular/core';
import { Router, RouterOutlet, NavigationEnd } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FooterComponent } from './components/shared/footer.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, FooterComponent],
  template: `
    <main>
      <router-outlet></router-outlet>
    </main>
    @if (!isHome) {
      <app-footer></app-footer>
    }
  `,
  styles: [`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      overflow-y: auto;
      -webkit-overflow-scrolling: touch;
    }

    :host.is-home {
      overflow-y: hidden;
    }

    main {
      flex: 1 0 auto;
    }
  `],
  host: {
    '[class.is-home]': 'isHome'
  }
})
export class AppComponent {
  private router = inject(Router);
  isHome = true;

  constructor() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.isHome = event.urlAfterRedirects === '/' || event.urlAfterRedirects === '';
      }
    });
  }
}
